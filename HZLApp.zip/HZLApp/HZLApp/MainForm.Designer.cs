﻿namespace HZLApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbz = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcolor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.cbglass = new System.Windows.Forms.ComboBox();
            this.cbadress = new System.Windows.Forms.ComboBox();
            this.cksf = new System.Windows.Forms.CheckedListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lkkh = new System.Windows.Forms.LinkLabel();
            this.lbcomid = new System.Windows.Forms.Label();
            this.panelNextPer = new System.Windows.Forms.Panel();
            this.lbcount = new System.Windows.Forms.Label();
            this.llper = new System.Windows.Forms.LinkLabel();
            this.llnext = new System.Windows.Forms.LinkLabel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.p4 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txt4gd = new System.Windows.Forms.TextBox();
            this.txt4cd = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.p11 = new System.Windows.Forms.Panel();
            this.bt1delete = new System.Windows.Forms.Button();
            this.txt1pfs = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt1ts = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt1dh = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.p1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt1gd = new System.Windows.Forms.TextBox();
            this.txt1cd = new System.Windows.Forms.TextBox();
            this.p2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txt2gd = new System.Windows.Forms.TextBox();
            this.txt2cd = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.p21 = new System.Windows.Forms.Panel();
            this.bt2delete = new System.Windows.Forms.Button();
            this.txt2pfs = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txt2ts = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txt2dh = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.txt3gd = new System.Windows.Forms.TextBox();
            this.txt3cd = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.p31 = new System.Windows.Forms.Panel();
            this.bt3delete = new System.Windows.Forms.Button();
            this.txt3pfs = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txt3ts = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txt3dh = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.p41 = new System.Windows.Forms.Panel();
            this.bt4delete = new System.Windows.Forms.Button();
            this.txt4pfs = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txt4ts = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txt4dh = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.p5 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.txt5gd = new System.Windows.Forms.TextBox();
            this.txt5cd = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.p51 = new System.Windows.Forms.Panel();
            this.bt5delete = new System.Windows.Forms.Button();
            this.txt5pfs = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txt5ts = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txt5dh = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.p6 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.txt6gd = new System.Windows.Forms.TextBox();
            this.txt6cd = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.p61 = new System.Windows.Forms.Panel();
            this.bt6delete = new System.Windows.Forms.Button();
            this.txt6pfs = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txt6ts = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txt6dh = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnsave = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtzts = new System.Windows.Forms.TextBox();
            this.txtdj = new System.Windows.Forms.TextBox();
            this.txtzpfs = new System.Windows.Forms.TextBox();
            this.txtzje = new System.Windows.Forms.TextBox();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panelNextPer.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.p4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.p11.SuspendLayout();
            this.p1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.p2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.p21.SuspendLayout();
            this.p3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.p31.SuspendLayout();
            this.p41.SuspendLayout();
            this.p5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.p51.SuspendLayout();
            this.p6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.p61.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox1.Size = new System.Drawing.Size(2544, 1528);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupBox3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 43);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(8);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(2528, 1477);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(8, 155);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox2.Size = new System.Drawing.Size(2512, 279);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 10;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtbz, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label4, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtcolor, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtphone, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtname, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.cbglass, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.cbadress, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.cksf, 9, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnAdd, 9, 1);
            this.tableLayoutPanel2.Controls.Add(this.lkkh, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbcomid, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.panelNextPer, 8, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(8, 43);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(8);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(2496, 228);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(996, 114);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(249, 114);
            this.label5.TabIndex = 16;
            this.label5.Text = "地 址：";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbz
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.txtbz, 3);
            this.txtbz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtbz.Location = new System.Drawing.Point(257, 164);
            this.txtbz.Margin = new System.Windows.Forms.Padding(8, 50, 8, 8);
            this.txtbz.Name = "txtbz";
            this.txtbz.Size = new System.Drawing.Size(731, 42);
            this.txtbz.TabIndex = 13;
            this.txtbz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(8, 114);
            this.label7.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(233, 114);
            this.label7.TabIndex = 12;
            this.label7.Text = "备 注：";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(2000, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(233, 114);
            this.label4.TabIndex = 8;
            this.label4.Text = "玻璃是否钢化：";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(1502, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(233, 114);
            this.label3.TabIndex = 6;
            this.label3.Text = "玻 璃：";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtcolor
            // 
            this.txtcolor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtcolor.Location = new System.Drawing.Point(1253, 50);
            this.txtcolor.Margin = new System.Windows.Forms.Padding(8, 50, 8, 8);
            this.txtcolor.Name = "txtcolor";
            this.txtcolor.Size = new System.Drawing.Size(233, 42);
            this.txtcolor.TabIndex = 5;
            this.txtcolor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(1004, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 114);
            this.label2.TabIndex = 4;
            this.label2.Text = "颜色：";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtphone
            // 
            this.txtphone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtphone.Location = new System.Drawing.Point(755, 50);
            this.txtphone.Margin = new System.Windows.Forms.Padding(8, 50, 8, 8);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(233, 42);
            this.txtphone.TabIndex = 3;
            this.txtphone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(506, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 114);
            this.label1.TabIndex = 2;
            this.label1.Text = "电 话：";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtname
            // 
            this.txtname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtname.Location = new System.Drawing.Point(257, 50);
            this.txtname.Margin = new System.Windows.Forms.Padding(8, 50, 8, 8);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(233, 42);
            this.txtname.TabIndex = 1;
            this.txtname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            // 
            // cbglass
            // 
            this.cbglass.FormattingEnabled = true;
            this.cbglass.Location = new System.Drawing.Point(1751, 50);
            this.cbglass.Margin = new System.Windows.Forms.Padding(8, 50, 8, 8);
            this.cbglass.Name = "cbglass";
            this.cbglass.Size = new System.Drawing.Size(232, 38);
            this.cbglass.TabIndex = 14;
            // 
            // cbadress
            // 
            this.cbadress.FormattingEnabled = true;
            this.cbadress.Location = new System.Drawing.Point(1253, 164);
            this.cbadress.Margin = new System.Windows.Forms.Padding(8, 50, 8, 8);
            this.cbadress.Name = "cbadress";
            this.cbadress.Size = new System.Drawing.Size(232, 38);
            this.cbadress.TabIndex = 15;
            // 
            // cksf
            // 
            this.cksf.BackColor = System.Drawing.SystemColors.Control;
            this.cksf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cksf.FormattingEnabled = true;
            this.cksf.Items.AddRange(new object[] {
            "是",
            "否"});
            this.cksf.Location = new System.Drawing.Point(2249, 8);
            this.cksf.Margin = new System.Windows.Forms.Padding(8);
            this.cksf.Name = "cksf";
            this.cksf.Size = new System.Drawing.Size(239, 98);
            this.cksf.TabIndex = 17;
            this.cksf.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.cksf_ItemCheck);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(2249, 122);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(8);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(239, 70);
            this.btnAdd.TabIndex = 18;
            this.btnAdd.Text = "添加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lkkh
            // 
            this.lkkh.AutoSize = true;
            this.lkkh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lkkh.Location = new System.Drawing.Point(8, 50);
            this.lkkh.Margin = new System.Windows.Forms.Padding(8, 50, 8, 0);
            this.lkkh.Name = "lkkh";
            this.lkkh.Size = new System.Drawing.Size(233, 64);
            this.lkkh.TabIndex = 20;
            this.lkkh.TabStop = true;
            this.lkkh.Text = "客户姓名：";
            this.lkkh.Click += new System.EventHandler(this.lkkh_Click);
            // 
            // lbcomid
            // 
            this.lbcomid.AutoSize = true;
            this.lbcomid.Location = new System.Drawing.Point(1751, 114);
            this.lbcomid.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbcomid.Name = "lbcomid";
            this.lbcomid.Size = new System.Drawing.Size(0, 30);
            this.lbcomid.TabIndex = 21;
            // 
            // panelNextPer
            // 
            this.panelNextPer.Controls.Add(this.lbcount);
            this.panelNextPer.Controls.Add(this.llper);
            this.panelNextPer.Controls.Add(this.llnext);
            this.panelNextPer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelNextPer.Location = new System.Drawing.Point(2000, 122);
            this.panelNextPer.Margin = new System.Windows.Forms.Padding(8);
            this.panelNextPer.Name = "panelNextPer";
            this.panelNextPer.Size = new System.Drawing.Size(233, 98);
            this.panelNextPer.TabIndex = 22;
            // 
            // lbcount
            // 
            this.lbcount.AutoSize = true;
            this.lbcount.ForeColor = System.Drawing.Color.Red;
            this.lbcount.Location = new System.Drawing.Point(12, 2);
            this.lbcount.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbcount.Name = "lbcount";
            this.lbcount.Size = new System.Drawing.Size(223, 30);
            this.lbcount.TabIndex = 22;
            this.lbcount.Text = "一共有0页，0项";
            // 
            // llper
            // 
            this.llper.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llper.AutoSize = true;
            this.llper.Location = new System.Drawing.Point(8, 60);
            this.llper.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.llper.Name = "llper";
            this.llper.Size = new System.Drawing.Size(103, 30);
            this.llper.TabIndex = 21;
            this.llper.TabStop = true;
            this.llper.Text = "上一页";
            this.llper.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llper_LinkClicked);
            // 
            // llnext
            // 
            this.llnext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.llnext.AutoSize = true;
            this.llnext.Location = new System.Drawing.Point(123, 60);
            this.llnext.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.llnext.Name = "llnext";
            this.llnext.Size = new System.Drawing.Size(103, 30);
            this.llnext.TabIndex = 20;
            this.llnext.TabStop = true;
            this.llnext.Text = "下一页";
            this.llnext.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llnext_LinkClicked);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel4);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(8, 450);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(8);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox3.Size = new System.Drawing.Size(2512, 722);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.33333F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.33333F));
            this.tableLayoutPanel4.Controls.Add(this.p4, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.p11, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.p1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.p2, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.p21, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.p3, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.p31, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.p41, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.p5, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.p51, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.p6, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.p61, 5, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(8, 43);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(8);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(2496, 671);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // p4
            // 
            this.p4.Controls.Add(this.pictureBox4);
            this.p4.Controls.Add(this.txt4gd);
            this.p4.Controls.Add(this.txt4cd);
            this.p4.Controls.Add(this.label16);
            this.p4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p4.Location = new System.Drawing.Point(8, 343);
            this.p4.Margin = new System.Windows.Forms.Padding(8);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(483, 320);
            this.p4.TabIndex = 2;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(95, 60);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(8);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(350, 260);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseClick);
            // 
            // txt4gd
            // 
            this.txt4gd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt4gd.Location = new System.Drawing.Point(13, 154);
            this.txt4gd.Margin = new System.Windows.Forms.Padding(8);
            this.txt4gd.Name = "txt4gd";
            this.txt4gd.Size = new System.Drawing.Size(66, 42);
            this.txt4gd.TabIndex = 2;
            this.txt4gd.Text = "0";
            this.txt4gd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt4gd_KeyDown);
            // 
            // txt4cd
            // 
            this.txt4cd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt4cd.Location = new System.Drawing.Point(166, 10);
            this.txt4cd.Margin = new System.Windows.Forms.Padding(8);
            this.txt4cd.Name = "txt4cd";
            this.txt4cd.Size = new System.Drawing.Size(132, 42);
            this.txt4cd.TabIndex = 1;
            this.txt4cd.Text = "0";
            this.txt4cd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt4cd_KeyDown);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 13);
            this.label16.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(163, 30);
            this.label16.TabIndex = 0;
            this.label16.Text = "尺寸：    ";
            // 
            // p11
            // 
            this.p11.Controls.Add(this.bt1delete);
            this.p11.Controls.Add(this.txt1pfs);
            this.p11.Controls.Add(this.label14);
            this.p11.Controls.Add(this.txt1ts);
            this.p11.Controls.Add(this.label13);
            this.p11.Controls.Add(this.txt1dh);
            this.p11.Controls.Add(this.label12);
            this.p11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p11.Location = new System.Drawing.Point(507, 8);
            this.p11.Margin = new System.Windows.Forms.Padding(8);
            this.p11.Name = "p11";
            this.p11.Size = new System.Drawing.Size(316, 319);
            this.p11.TabIndex = 0;
            // 
            // bt1delete
            // 
            this.bt1delete.Location = new System.Drawing.Point(42, 262);
            this.bt1delete.Margin = new System.Windows.Forms.Padding(8);
            this.bt1delete.Name = "bt1delete";
            this.bt1delete.Size = new System.Drawing.Size(188, 58);
            this.bt1delete.TabIndex = 6;
            this.bt1delete.Text = "删除";
            this.bt1delete.UseVisualStyleBackColor = true;
            this.bt1delete.Click += new System.EventHandler(this.bt1delete_Click);
            // 
            // txt1pfs
            // 
            this.txt1pfs.BackColor = System.Drawing.SystemColors.Control;
            this.txt1pfs.Location = new System.Drawing.Point(138, 202);
            this.txt1pfs.Margin = new System.Windows.Forms.Padding(8);
            this.txt1pfs.Name = "txt1pfs";
            this.txt1pfs.ReadOnly = true;
            this.txt1pfs.Size = new System.Drawing.Size(151, 42);
            this.txt1pfs.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(2, 202);
            this.label14.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 30);
            this.label14.TabIndex = 4;
            this.label14.Text = "平方数:";
            // 
            // txt1ts
            // 
            this.txt1ts.Location = new System.Drawing.Point(138, 130);
            this.txt1ts.Margin = new System.Windows.Forms.Padding(8);
            this.txt1ts.Name = "txt1ts";
            this.txt1ts.Size = new System.Drawing.Size(151, 42);
            this.txt1ts.TabIndex = 3;
            this.txt1ts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt1ts_KeyDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(2, 130);
            this.label13.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 30);
            this.label13.TabIndex = 2;
            this.label13.Text = "樘数:";
            // 
            // txt1dh
            // 
            this.txt1dh.BackColor = System.Drawing.SystemColors.Control;
            this.txt1dh.Location = new System.Drawing.Point(138, 55);
            this.txt1dh.Margin = new System.Windows.Forms.Padding(8);
            this.txt1dh.Name = "txt1dh";
            this.txt1dh.Size = new System.Drawing.Size(151, 42);
            this.txt1dh.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(2, 55);
            this.label12.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 30);
            this.label12.TabIndex = 0;
            this.label12.Text = "代号:";
            // 
            // p1
            // 
            this.p1.Controls.Add(this.pictureBox1);
            this.p1.Controls.Add(this.txt1gd);
            this.p1.Controls.Add(this.txt1cd);
            this.p1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p1.Location = new System.Drawing.Point(8, 8);
            this.p1.Margin = new System.Windows.Forms.Padding(8);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(483, 319);
            this.p1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(95, 60);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(350, 260);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            // 
            // txt1gd
            // 
            this.txt1gd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt1gd.Location = new System.Drawing.Point(13, 135);
            this.txt1gd.Margin = new System.Windows.Forms.Padding(8);
            this.txt1gd.Name = "txt1gd";
            this.txt1gd.Size = new System.Drawing.Size(66, 42);
            this.txt1gd.TabIndex = 2;
            this.txt1gd.Text = "0";
            this.txt1gd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt1gd_KeyDown);
            // 
            // txt1cd
            // 
            this.txt1cd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt1cd.Location = new System.Drawing.Point(166, 5);
            this.txt1cd.Margin = new System.Windows.Forms.Padding(8);
            this.txt1cd.Name = "txt1cd";
            this.txt1cd.Size = new System.Drawing.Size(132, 42);
            this.txt1cd.TabIndex = 1;
            this.txt1cd.Text = "0";
            this.txt1cd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt1cd_KeyDown);
            // 
            // p2
            // 
            this.p2.Controls.Add(this.pictureBox2);
            this.p2.Controls.Add(this.txt2gd);
            this.p2.Controls.Add(this.txt2cd);
            this.p2.Controls.Add(this.label17);
            this.p2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p2.Location = new System.Drawing.Point(839, 8);
            this.p2.Margin = new System.Windows.Forms.Padding(8);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(483, 319);
            this.p2.TabIndex = 3;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(130, 68);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(350, 260);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseClick);
            // 
            // txt2gd
            // 
            this.txt2gd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt2gd.Location = new System.Drawing.Point(42, 160);
            this.txt2gd.Margin = new System.Windows.Forms.Padding(8);
            this.txt2gd.Name = "txt2gd";
            this.txt2gd.Size = new System.Drawing.Size(66, 42);
            this.txt2gd.TabIndex = 6;
            this.txt2gd.Text = "0";
            this.txt2gd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt2gd_KeyDown);
            // 
            // txt2cd
            // 
            this.txt2cd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt2cd.Location = new System.Drawing.Point(201, 0);
            this.txt2cd.Margin = new System.Windows.Forms.Padding(8);
            this.txt2cd.Name = "txt2cd";
            this.txt2cd.Size = new System.Drawing.Size(132, 42);
            this.txt2cd.TabIndex = 5;
            this.txt2cd.Text = "0";
            this.txt2cd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt2cd_KeyDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(42, 10);
            this.label17.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(163, 30);
            this.label17.TabIndex = 4;
            this.label17.Text = "尺寸：    ";
            // 
            // p21
            // 
            this.p21.Controls.Add(this.bt2delete);
            this.p21.Controls.Add(this.txt2pfs);
            this.p21.Controls.Add(this.label21);
            this.p21.Controls.Add(this.txt2ts);
            this.p21.Controls.Add(this.label22);
            this.p21.Controls.Add(this.txt2dh);
            this.p21.Controls.Add(this.label23);
            this.p21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p21.Location = new System.Drawing.Point(1338, 8);
            this.p21.Margin = new System.Windows.Forms.Padding(8);
            this.p21.Name = "p21";
            this.p21.Size = new System.Drawing.Size(316, 319);
            this.p21.TabIndex = 4;
            // 
            // bt2delete
            // 
            this.bt2delete.Location = new System.Drawing.Point(72, 270);
            this.bt2delete.Margin = new System.Windows.Forms.Padding(8);
            this.bt2delete.Name = "bt2delete";
            this.bt2delete.Size = new System.Drawing.Size(188, 58);
            this.bt2delete.TabIndex = 12;
            this.bt2delete.Text = "删除";
            this.bt2delete.UseVisualStyleBackColor = true;
            this.bt2delete.Click += new System.EventHandler(this.bt2delete_Click);
            // 
            // txt2pfs
            // 
            this.txt2pfs.BackColor = System.Drawing.SystemColors.Control;
            this.txt2pfs.Location = new System.Drawing.Point(140, 210);
            this.txt2pfs.Margin = new System.Windows.Forms.Padding(8);
            this.txt2pfs.Name = "txt2pfs";
            this.txt2pfs.ReadOnly = true;
            this.txt2pfs.Size = new System.Drawing.Size(151, 42);
            this.txt2pfs.TabIndex = 11;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(5, 210);
            this.label21.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(118, 30);
            this.label21.TabIndex = 10;
            this.label21.Text = "平方数:";
            // 
            // txt2ts
            // 
            this.txt2ts.Location = new System.Drawing.Point(140, 138);
            this.txt2ts.Margin = new System.Windows.Forms.Padding(8);
            this.txt2ts.Name = "txt2ts";
            this.txt2ts.Size = new System.Drawing.Size(151, 42);
            this.txt2ts.TabIndex = 9;
            this.txt2ts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt2ts_KeyDown);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(5, 138);
            this.label22.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(88, 30);
            this.label22.TabIndex = 8;
            this.label22.Text = "樘数:";
            // 
            // txt2dh
            // 
            this.txt2dh.BackColor = System.Drawing.SystemColors.Control;
            this.txt2dh.Location = new System.Drawing.Point(140, 62);
            this.txt2dh.Margin = new System.Windows.Forms.Padding(8);
            this.txt2dh.Name = "txt2dh";
            this.txt2dh.Size = new System.Drawing.Size(151, 42);
            this.txt2dh.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(5, 62);
            this.label23.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(88, 30);
            this.label23.TabIndex = 6;
            this.label23.Text = "代号:";
            // 
            // p3
            // 
            this.p3.Controls.Add(this.pictureBox3);
            this.p3.Controls.Add(this.txt3gd);
            this.p3.Controls.Add(this.txt3cd);
            this.p3.Controls.Add(this.label18);
            this.p3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p3.Location = new System.Drawing.Point(1670, 8);
            this.p3.Margin = new System.Windows.Forms.Padding(8);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(483, 319);
            this.p3.TabIndex = 5;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(92, 62);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(8);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(350, 260);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseClick);
            // 
            // txt3gd
            // 
            this.txt3gd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt3gd.Location = new System.Drawing.Point(5, 155);
            this.txt3gd.Margin = new System.Windows.Forms.Padding(8);
            this.txt3gd.Name = "txt3gd";
            this.txt3gd.Size = new System.Drawing.Size(66, 42);
            this.txt3gd.TabIndex = 6;
            this.txt3gd.Text = "0";
            this.txt3gd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt3gd_KeyDown);
            // 
            // txt3cd
            // 
            this.txt3cd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt3cd.Location = new System.Drawing.Point(181, 0);
            this.txt3cd.Margin = new System.Windows.Forms.Padding(8);
            this.txt3cd.Name = "txt3cd";
            this.txt3cd.Size = new System.Drawing.Size(132, 42);
            this.txt3cd.TabIndex = 5;
            this.txt3cd.Text = "0";
            this.txt3cd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt3cd_KeyDown);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 8);
            this.label18.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(163, 30);
            this.label18.TabIndex = 4;
            this.label18.Text = "尺寸：    ";
            // 
            // p31
            // 
            this.p31.Controls.Add(this.bt3delete);
            this.p31.Controls.Add(this.txt3pfs);
            this.p31.Controls.Add(this.label24);
            this.p31.Controls.Add(this.txt3ts);
            this.p31.Controls.Add(this.label25);
            this.p31.Controls.Add(this.txt3dh);
            this.p31.Controls.Add(this.label26);
            this.p31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p31.Location = new System.Drawing.Point(2169, 8);
            this.p31.Margin = new System.Windows.Forms.Padding(8);
            this.p31.Name = "p31";
            this.p31.Size = new System.Drawing.Size(319, 319);
            this.p31.TabIndex = 6;
            // 
            // bt3delete
            // 
            this.bt3delete.Location = new System.Drawing.Point(92, 270);
            this.bt3delete.Margin = new System.Windows.Forms.Padding(8);
            this.bt3delete.Name = "bt3delete";
            this.bt3delete.Size = new System.Drawing.Size(188, 58);
            this.bt3delete.TabIndex = 13;
            this.bt3delete.Text = "删除";
            this.bt3delete.UseVisualStyleBackColor = true;
            this.bt3delete.Click += new System.EventHandler(this.bt3delete_Click);
            // 
            // txt3pfs
            // 
            this.txt3pfs.BackColor = System.Drawing.SystemColors.Control;
            this.txt3pfs.Location = new System.Drawing.Point(145, 210);
            this.txt3pfs.Margin = new System.Windows.Forms.Padding(8);
            this.txt3pfs.Name = "txt3pfs";
            this.txt3pfs.ReadOnly = true;
            this.txt3pfs.Size = new System.Drawing.Size(156, 42);
            this.txt3pfs.TabIndex = 11;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 210);
            this.label24.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(118, 30);
            this.label24.TabIndex = 10;
            this.label24.Text = "平方数:";
            // 
            // txt3ts
            // 
            this.txt3ts.Location = new System.Drawing.Point(144, 138);
            this.txt3ts.Margin = new System.Windows.Forms.Padding(8);
            this.txt3ts.Name = "txt3ts";
            this.txt3ts.Size = new System.Drawing.Size(157, 42);
            this.txt3ts.TabIndex = 9;
            this.txt3ts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt3ts_KeyDown);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 138);
            this.label25.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 30);
            this.label25.TabIndex = 8;
            this.label25.Text = "樘数:";
            // 
            // txt3dh
            // 
            this.txt3dh.BackColor = System.Drawing.SystemColors.Control;
            this.txt3dh.Location = new System.Drawing.Point(145, 68);
            this.txt3dh.Margin = new System.Windows.Forms.Padding(8);
            this.txt3dh.Name = "txt3dh";
            this.txt3dh.Size = new System.Drawing.Size(156, 42);
            this.txt3dh.TabIndex = 7;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 62);
            this.label26.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 30);
            this.label26.TabIndex = 6;
            this.label26.Text = "代号:";
            // 
            // p41
            // 
            this.p41.Controls.Add(this.bt4delete);
            this.p41.Controls.Add(this.txt4pfs);
            this.p41.Controls.Add(this.label33);
            this.p41.Controls.Add(this.txt4ts);
            this.p41.Controls.Add(this.label34);
            this.p41.Controls.Add(this.txt4dh);
            this.p41.Controls.Add(this.label35);
            this.p41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p41.Location = new System.Drawing.Point(507, 343);
            this.p41.Margin = new System.Windows.Forms.Padding(8);
            this.p41.Name = "p41";
            this.p41.Size = new System.Drawing.Size(316, 320);
            this.p41.TabIndex = 7;
            // 
            // bt4delete
            // 
            this.bt4delete.Location = new System.Drawing.Point(42, 262);
            this.bt4delete.Margin = new System.Windows.Forms.Padding(8);
            this.bt4delete.Name = "bt4delete";
            this.bt4delete.Size = new System.Drawing.Size(188, 58);
            this.bt4delete.TabIndex = 14;
            this.bt4delete.Text = "删除";
            this.bt4delete.UseVisualStyleBackColor = true;
            this.bt4delete.Click += new System.EventHandler(this.bt4delete_Click);
            // 
            // txt4pfs
            // 
            this.txt4pfs.BackColor = System.Drawing.SystemColors.Control;
            this.txt4pfs.Location = new System.Drawing.Point(128, 200);
            this.txt4pfs.Margin = new System.Windows.Forms.Padding(8);
            this.txt4pfs.Name = "txt4pfs";
            this.txt4pfs.ReadOnly = true;
            this.txt4pfs.Size = new System.Drawing.Size(161, 42);
            this.txt4pfs.TabIndex = 11;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(-8, 200);
            this.label33.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(118, 30);
            this.label33.TabIndex = 10;
            this.label33.Text = "平方数:";
            // 
            // txt4ts
            // 
            this.txt4ts.Location = new System.Drawing.Point(128, 128);
            this.txt4ts.Margin = new System.Windows.Forms.Padding(8);
            this.txt4ts.Name = "txt4ts";
            this.txt4ts.Size = new System.Drawing.Size(161, 42);
            this.txt4ts.TabIndex = 9;
            this.txt4ts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt4ts_KeyDown);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(-8, 128);
            this.label34.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(88, 30);
            this.label34.TabIndex = 8;
            this.label34.Text = "樘数:";
            // 
            // txt4dh
            // 
            this.txt4dh.BackColor = System.Drawing.SystemColors.Control;
            this.txt4dh.Location = new System.Drawing.Point(128, 52);
            this.txt4dh.Margin = new System.Windows.Forms.Padding(8);
            this.txt4dh.Name = "txt4dh";
            this.txt4dh.Size = new System.Drawing.Size(161, 42);
            this.txt4dh.TabIndex = 7;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(-8, 52);
            this.label35.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(88, 30);
            this.label35.TabIndex = 6;
            this.label35.Text = "代号:";
            // 
            // p5
            // 
            this.p5.Controls.Add(this.pictureBox5);
            this.p5.Controls.Add(this.txt5gd);
            this.p5.Controls.Add(this.txt5cd);
            this.p5.Controls.Add(this.label20);
            this.p5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p5.Location = new System.Drawing.Point(839, 343);
            this.p5.Margin = new System.Windows.Forms.Padding(8);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(483, 320);
            this.p5.TabIndex = 8;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(130, 68);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(8);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(350, 260);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox5_MouseClick);
            // 
            // txt5gd
            // 
            this.txt5gd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt5gd.Location = new System.Drawing.Point(42, 161);
            this.txt5gd.Margin = new System.Windows.Forms.Padding(8);
            this.txt5gd.Name = "txt5gd";
            this.txt5gd.Size = new System.Drawing.Size(66, 42);
            this.txt5gd.TabIndex = 6;
            this.txt5gd.Text = "0";
            this.txt5gd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt5gd_KeyDown);
            // 
            // txt5cd
            // 
            this.txt5cd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt5cd.Location = new System.Drawing.Point(201, 10);
            this.txt5cd.Margin = new System.Windows.Forms.Padding(8);
            this.txt5cd.Name = "txt5cd";
            this.txt5cd.Size = new System.Drawing.Size(132, 42);
            this.txt5cd.TabIndex = 5;
            this.txt5cd.Text = "0";
            this.txt5cd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt5cd_KeyDown);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(37, 13);
            this.label20.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(163, 30);
            this.label20.TabIndex = 4;
            this.label20.Text = "尺寸：    ";
            // 
            // p51
            // 
            this.p51.Controls.Add(this.bt5delete);
            this.p51.Controls.Add(this.txt5pfs);
            this.p51.Controls.Add(this.label30);
            this.p51.Controls.Add(this.txt5ts);
            this.p51.Controls.Add(this.label31);
            this.p51.Controls.Add(this.txt5dh);
            this.p51.Controls.Add(this.label32);
            this.p51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p51.Location = new System.Drawing.Point(1338, 343);
            this.p51.Margin = new System.Windows.Forms.Padding(8);
            this.p51.Name = "p51";
            this.p51.Size = new System.Drawing.Size(316, 320);
            this.p51.TabIndex = 9;
            // 
            // bt5delete
            // 
            this.bt5delete.Location = new System.Drawing.Point(72, 270);
            this.bt5delete.Margin = new System.Windows.Forms.Padding(8);
            this.bt5delete.Name = "bt5delete";
            this.bt5delete.Size = new System.Drawing.Size(188, 58);
            this.bt5delete.TabIndex = 14;
            this.bt5delete.Text = "删除";
            this.bt5delete.UseVisualStyleBackColor = true;
            this.bt5delete.Click += new System.EventHandler(this.bt5delete_Click);
            // 
            // txt5pfs
            // 
            this.txt5pfs.BackColor = System.Drawing.SystemColors.Control;
            this.txt5pfs.Location = new System.Drawing.Point(142, 215);
            this.txt5pfs.Margin = new System.Windows.Forms.Padding(8);
            this.txt5pfs.Name = "txt5pfs";
            this.txt5pfs.ReadOnly = true;
            this.txt5pfs.Size = new System.Drawing.Size(149, 42);
            this.txt5pfs.TabIndex = 11;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(8, 215);
            this.label30.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(118, 30);
            this.label30.TabIndex = 10;
            this.label30.Text = "平方数:";
            // 
            // txt5ts
            // 
            this.txt5ts.Location = new System.Drawing.Point(142, 142);
            this.txt5ts.Margin = new System.Windows.Forms.Padding(8);
            this.txt5ts.Name = "txt5ts";
            this.txt5ts.Size = new System.Drawing.Size(149, 42);
            this.txt5ts.TabIndex = 9;
            this.txt5ts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt5ts_KeyDown);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(8, 142);
            this.label31.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(88, 30);
            this.label31.TabIndex = 8;
            this.label31.Text = "樘数:";
            // 
            // txt5dh
            // 
            this.txt5dh.BackColor = System.Drawing.SystemColors.Control;
            this.txt5dh.Location = new System.Drawing.Point(142, 68);
            this.txt5dh.Margin = new System.Windows.Forms.Padding(8);
            this.txt5dh.Name = "txt5dh";
            this.txt5dh.Size = new System.Drawing.Size(149, 42);
            this.txt5dh.TabIndex = 7;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(8, 68);
            this.label32.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(88, 30);
            this.label32.TabIndex = 6;
            this.label32.Text = "代号:";
            // 
            // p6
            // 
            this.p6.Controls.Add(this.pictureBox6);
            this.p6.Controls.Add(this.txt6gd);
            this.p6.Controls.Add(this.txt6cd);
            this.p6.Controls.Add(this.label19);
            this.p6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p6.Location = new System.Drawing.Point(1670, 343);
            this.p6.Margin = new System.Windows.Forms.Padding(8);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(483, 320);
            this.p6.TabIndex = 10;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(92, 60);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(8);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(350, 260);
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox6_MouseClick);
            // 
            // txt6gd
            // 
            this.txt6gd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt6gd.Location = new System.Drawing.Point(5, 154);
            this.txt6gd.Margin = new System.Windows.Forms.Padding(8);
            this.txt6gd.Name = "txt6gd";
            this.txt6gd.Size = new System.Drawing.Size(66, 42);
            this.txt6gd.TabIndex = 6;
            this.txt6gd.Text = "0";
            this.txt6gd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt6gd_KeyDown);
            // 
            // txt6cd
            // 
            this.txt6cd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt6cd.Location = new System.Drawing.Point(181, 10);
            this.txt6cd.Margin = new System.Windows.Forms.Padding(8);
            this.txt6cd.Name = "txt6cd";
            this.txt6cd.Size = new System.Drawing.Size(132, 42);
            this.txt6cd.TabIndex = 5;
            this.txt6cd.Text = "0";
            this.txt6cd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt6cd_KeyDown);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 10);
            this.label19.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(163, 30);
            this.label19.TabIndex = 4;
            this.label19.Text = "尺寸：    ";
            // 
            // p61
            // 
            this.p61.Controls.Add(this.bt6delete);
            this.p61.Controls.Add(this.txt6pfs);
            this.p61.Controls.Add(this.label27);
            this.p61.Controls.Add(this.txt6ts);
            this.p61.Controls.Add(this.label28);
            this.p61.Controls.Add(this.txt6dh);
            this.p61.Controls.Add(this.label29);
            this.p61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.p61.Location = new System.Drawing.Point(2169, 343);
            this.p61.Margin = new System.Windows.Forms.Padding(8);
            this.p61.Name = "p61";
            this.p61.Size = new System.Drawing.Size(319, 320);
            this.p61.TabIndex = 11;
            // 
            // bt6delete
            // 
            this.bt6delete.Location = new System.Drawing.Point(92, 270);
            this.bt6delete.Margin = new System.Windows.Forms.Padding(8);
            this.bt6delete.Name = "bt6delete";
            this.bt6delete.Size = new System.Drawing.Size(188, 58);
            this.bt6delete.TabIndex = 14;
            this.bt6delete.Text = "删除";
            this.bt6delete.UseVisualStyleBackColor = true;
            this.bt6delete.Click += new System.EventHandler(this.bt6delete_Click);
            // 
            // txt6pfs
            // 
            this.txt6pfs.BackColor = System.Drawing.SystemColors.Control;
            this.txt6pfs.Location = new System.Drawing.Point(145, 200);
            this.txt6pfs.Margin = new System.Windows.Forms.Padding(8);
            this.txt6pfs.Name = "txt6pfs";
            this.txt6pfs.ReadOnly = true;
            this.txt6pfs.Size = new System.Drawing.Size(166, 42);
            this.txt6pfs.TabIndex = 11;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 208);
            this.label27.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(118, 30);
            this.label27.TabIndex = 10;
            this.label27.Text = "平方数:";
            // 
            // txt6ts
            // 
            this.txt6ts.Location = new System.Drawing.Point(145, 139);
            this.txt6ts.Margin = new System.Windows.Forms.Padding(8);
            this.txt6ts.Name = "txt6ts";
            this.txt6ts.Size = new System.Drawing.Size(166, 42);
            this.txt6ts.TabIndex = 9;
            this.txt6ts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt6ts_KeyDown);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 135);
            this.label28.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 30);
            this.label28.TabIndex = 8;
            this.label28.Text = "樘数:";
            // 
            // txt6dh
            // 
            this.txt6dh.BackColor = System.Drawing.SystemColors.Control;
            this.txt6dh.Location = new System.Drawing.Point(145, 57);
            this.txt6dh.Margin = new System.Windows.Forms.Padding(8);
            this.txt6dh.Name = "txt6dh";
            this.txt6dh.Size = new System.Drawing.Size(166, 42);
            this.txt6dh.TabIndex = 7;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 60);
            this.label29.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(88, 30);
            this.label29.TabIndex = 6;
            this.label29.Text = "代号:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("SimSun", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(8, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(2512, 147);
            this.label6.TabIndex = 4;
            this.label6.Text = "安徽澳普斯成品厅门窗设计图";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(8, 1188);
            this.panel1.Margin = new System.Windows.Forms.Padding(8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2512, 281);
            this.panel1.TabIndex = 5;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 7;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Controls.Add(this.panel2, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label8, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label10, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.label11, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtzts, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtdj, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.txtzpfs, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtzje, 5, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(8);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(2512, 281);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // panel2
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.panel2, 7);
            this.panel2.Controls.Add(this.btnsave);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(8, 204);
            this.panel2.Margin = new System.Windows.Forms.Padding(8);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(2496, 69);
            this.panel2.TabIndex = 0;
            // 
            // btnsave
            // 
            this.btnsave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnsave.Location = new System.Drawing.Point(2270, 19);
            this.btnsave.Margin = new System.Windows.Forms.Padding(8);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(188, 58);
            this.btnsave.TabIndex = 0;
            this.btnsave.Text = "保存打印";
            this.btnsave.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(259, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(360, 98);
            this.label8.TabIndex = 1;
            this.label8.Text = "总樘数:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(259, 98);
            this.label9.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(360, 98);
            this.label9.TabIndex = 2;
            this.label9.Text = "单 价:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(1513, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(360, 98);
            this.label10.TabIndex = 3;
            this.label10.Text = "总平方数：";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(1513, 98);
            this.label11.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(360, 98);
            this.label11.TabIndex = 4;
            this.label11.Text = "总金额：";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtzts
            // 
            this.txtzts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtzts.Location = new System.Drawing.Point(635, 32);
            this.txtzts.Margin = new System.Windows.Forms.Padding(8, 32, 8, 8);
            this.txtzts.Name = "txtzts";
            this.txtzts.Size = new System.Drawing.Size(360, 42);
            this.txtzts.TabIndex = 5;
            this.txtzts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtdj
            // 
            this.txtdj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtdj.Location = new System.Drawing.Point(635, 130);
            this.txtdj.Margin = new System.Windows.Forms.Padding(8, 32, 8, 8);
            this.txtdj.Name = "txtdj";
            this.txtdj.Size = new System.Drawing.Size(360, 42);
            this.txtdj.TabIndex = 6;
            this.txtdj.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtdj.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtdj_KeyDown);
            // 
            // txtzpfs
            // 
            this.txtzpfs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtzpfs.Location = new System.Drawing.Point(1889, 32);
            this.txtzpfs.Margin = new System.Windows.Forms.Padding(8, 32, 8, 8);
            this.txtzpfs.Name = "txtzpfs";
            this.txtzpfs.Size = new System.Drawing.Size(360, 42);
            this.txtzpfs.TabIndex = 7;
            this.txtzpfs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtzje
            // 
            this.txtzje.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtzje.Location = new System.Drawing.Point(1889, 130);
            this.txtzje.Margin = new System.Windows.Forms.Padding(8, 32, 8, 8);
            this.txtzje.Name = "txtzje";
            this.txtzje.Size = new System.Drawing.Size(360, 42);
            this.txtzje.TabIndex = 8;
            this.txtzje.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2544, 1528);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panelNextPer.ResumeLayout(false);
            this.panelNextPer.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.p4.ResumeLayout(false);
            this.p4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.p11.ResumeLayout(false);
            this.p11.PerformLayout();
            this.p1.ResumeLayout(false);
            this.p1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.p2.ResumeLayout(false);
            this.p2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.p21.ResumeLayout(false);
            this.p21.PerformLayout();
            this.p3.ResumeLayout(false);
            this.p3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.p31.ResumeLayout(false);
            this.p31.PerformLayout();
            this.p41.ResumeLayout(false);
            this.p41.PerformLayout();
            this.p5.ResumeLayout(false);
            this.p5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.p51.ResumeLayout(false);
            this.p51.PerformLayout();
            this.p6.ResumeLayout(false);
            this.p6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.p61.ResumeLayout(false);
            this.p61.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcolor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox cbglass;
        private System.Windows.Forms.ComboBox cbadress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtzts;
        private System.Windows.Forms.TextBox txtdj;
        private System.Windows.Forms.TextBox txtzpfs;
        private System.Windows.Forms.TextBox txtzje;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel p11;
        private System.Windows.Forms.TextBox txt1dh;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt1pfs;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt1ts;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.CheckedListBox cksf;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txt1gd;
        private System.Windows.Forms.TextBox txt1cd;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel p4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox txt4gd;
        private System.Windows.Forms.TextBox txt4cd;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel p2;
        private System.Windows.Forms.Panel p21;
        private System.Windows.Forms.Panel p3;
        private System.Windows.Forms.Panel p31;
        private System.Windows.Forms.Panel p41;
        private System.Windows.Forms.Panel p5;
        private System.Windows.Forms.Panel p51;
        private System.Windows.Forms.Panel p6;
        private System.Windows.Forms.Panel p61;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txt2gd;
        private System.Windows.Forms.TextBox txt2cd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt2pfs;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt2ts;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt2dh;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox txt3gd;
        private System.Windows.Forms.TextBox txt3cd;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt3pfs;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txt3ts;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txt3dh;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt4pfs;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txt4ts;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txt4dh;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox txt5gd;
        private System.Windows.Forms.TextBox txt5cd;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt5pfs;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt5ts;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txt5dh;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox txt6gd;
        private System.Windows.Forms.TextBox txt6cd;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt6pfs;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt6ts;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt6dh;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button bt1delete;
        private System.Windows.Forms.Button bt2delete;
        private System.Windows.Forms.Button bt3delete;
        private System.Windows.Forms.Button bt4delete;
        private System.Windows.Forms.Button bt5delete;
        private System.Windows.Forms.Button bt6delete;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbz;
        private System.Windows.Forms.LinkLabel lkkh;
        private System.Windows.Forms.Label lbcomid;
        private System.Windows.Forms.Panel panelNextPer;
        private System.Windows.Forms.LinkLabel llper;
        private System.Windows.Forms.LinkLabel llnext;
        private System.Windows.Forms.Label lbcount;


    }
}